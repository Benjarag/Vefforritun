/* Section 1: Convert to arrow functions*/
const testArrowFunctions = () => {
  const multiply = (a, b) => {
    return a * b;
  };
  console.log(multiply(4, 5));
};

/* Section 2: Use built-in array methods instead of loops*/
const testArrayMethods = () => {
  const numbers = [1, 2, 3, 4, 5];
  const doubled = numbers.map((n) => n * 2);
  console.log(doubled);
};

/*Section 3: Fetch data from an API*/
const fetchUserData = async () => {
  //The URL to which we will send the request
  const url = "https://jsonplaceholder.typicode.com/users";

  //Perform a GET request to the url
  try {
    const response = await axios.get(url);
    //When successful, print the received data
    console.log("Success: ", response.data);
    const users = response.data;
    const userList = document.getElementById("user-list");
    userList.innerHTML = ""; // Clear previous results
    users.forEach((user) => {
      const li = document.createElement("li");
      li.textContent = user.name;
      userList.appendChild(li);
    });
  } catch (error) {
    //When unsuccessful, print the error.
    console.log(error);
  }
  // This code is always executed, independent of whether the request succeeds or fails.
};

/*Section 4: Memory card matching game*/
const emojis = [
  "🍎",
  "🍌",
  "🍇",
  "🍉",
  "🍒",
  "🍍",
  "🍎",
  "🍌",
  "🍇",
  "🍉",
  "🍒",
  "🍍",
];
let shuffledEmojis = emojis.sort(() => 0.5 - Math.random());
let selectedCards = [];
let matchedPairs = 0;
const gameBoard = document.getElementById("game-board");

const createBoard = () => {
  gameBoard.innerHTML = "";
  shuffledEmojis.forEach((emoji, index) => {
    const card = document.createElement("div");
    card.classList.add("card");
    card.dataset.emoji = emoji;
    card.dataset.index = index;
    card.innerText = "❓";
    card.addEventListener("click", flipCard);
    gameBoard.appendChild(card);
  });
};

const resetGame = () => {
  shuffledEmojis = emojis.sort(() => 0.5 - Math.random());
  matchedPairs = 0;
  selectedCards = [];
  createBoard();
};

const flipCard = (event) => {
  const card = event.target;
  if (selectedCards.length < 2 && !card.classList.contains("matched")) {
    card.innerText = card.dataset.emoji;
    selectedCards.push(card);
  }
  if (selectedCards.length === 2) {
    setTimeout(checkMatch, 500);
  }
};

const checkMatch = () => {
  const [card1, card2] = selectedCards;
  if (card1.dataset.emoji === card2.dataset.emoji) {
    card1.classList.add("matched");
    card2.classList.add("matched");
    matchedPairs++;
    if (matchedPairs === emojis.length / 2) {
      setTimeout(() => alert("You win!"), 300);
    }
  } else {
    card1.innerText = "❓";
    card2.innerText = "❓";
  }
  selectedCards = [];
};

createBoard();

document.addEventListener("DOMContentLoaded", createBoard);

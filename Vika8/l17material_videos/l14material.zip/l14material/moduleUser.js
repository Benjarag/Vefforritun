//require is node syntax - won't work in the browser
var myModule = require('./myModule');
console.log(myModule.getSSID());
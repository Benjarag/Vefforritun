var axios = require('axios');

axios.get('http://localhost:3000');